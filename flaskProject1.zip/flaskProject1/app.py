import os
import string
from flask import Flask, request, render_template
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.ext.automap import automap_base
import psycopg2
from sqlalchemy import create_engine
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import sessionmaker
from flask import Flask, render_template, request, flash
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

# app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

app.config['SQLALCHEMY_DATABASE_URI'] = "postgresql://admin:admin@localhost/aircraft_db"

db = SQLAlchemy(app)

Base = automap_base()
Base.prepare(db.engine, reflect=True)
Incidents = Base.classes.incidents
Aircraft = Base.classes.aircraft
Casualties = Base.classes.casualties





# establishes connection to DB
def get_db_connection():
    conn = psycopg2.connect(host='localhost',
                            database='aircraft_db',
                            user='admin',
                            password='admin')
    return conn

# gets user entry from UI
def get_user_entry():
    aircraft_reg_num = request.form["aircraft_reg_num"]
    aircraft_model = request.form["aircraft_model"]
    aircraft_make = request.form["aircraft_make"]
    aircraft_event_ntsb_num = request.form["aircraft_event_ntsb_num"]
    casualties_id = request.form["casualties_id"]
    casualties_first_name = request.form["casualties_first_name"]
    casualties_last_name = request.form["casualties_last_name"]
    casualties_dob = request.form["casualties_dob"]
    casualties_age = request.form["casualties_age"]
    casualties_sex = request.form["casualties_sex"]
    casualties_event_ntsb_num = request.form["casualties_event_ntsb_num"]
    incident_event_ntsb = request.form["incident_event_ntsb"]
    incident_event_severity = request.form["incident_event_severity"]
    incident_event_date = request.form["incident_event_date"]
    incident_event_location = request.form["incident_event_location"]
    incident_aircraft_reg_num = request.form["incident_aircraft_reg_num"]
    user_input = aircraft_model + aircraft_make
    """if (aircraft_model != null)
    {
    	input_type = 'Aircraft Registration'
    }"""
    """user_entry_to_sql(input_type, user_input)
    return;"""


# takes in input_type: the data type of field entered (EX: Aircraft Registration Number) user input
# creates SQL query through SQLAlchemy

# Insert an aircraft
@app.route("/user_entry_to_sql", methods=['POST'])
def user_entry_to_sql():
    result_test = db.session.query(Aircraft).filter_by(aircraft_model='A234')
    return render_template("index.html", result_test=result_test)
    
    """
    if input_type == "Aircraft Registration":  # Input is entered into Aircraft Registration text field
        sql_query = session.query(Incidents).filter(Incidents.aircraft_reg_number == user_input).all()
    elif input_type == "Event Date":  # Input is entered into Event Date text field
        sql_query = session.query(Incidents).filter(Incidents.event_date == user_input).all()
    elif input_type == "NTSB Number":  # Input is entered into NTSB Number text field
        sql_query = session.query(Incidents).filter(Incidents.event_ntsb_number == user_input)
    elif input_type == "Aircraft Make":  # Input is entered into Aircraft Make text field
        sql_query = session.query(Incidents).join(Aircraft).filter(Aircraft.aircraft_make == user_input).all()
    elif input_type == "Aircraft Model":  # Input is entered into Aircraft Model text field
        sql_query = session.query(Incidents).join(Aircraft).filter(Aircraft.aircraft_model == user_input).all()
    elif input_type == "Event Location":  # Input is entered into Event Location text field
        sql_query = Incidents.query.filter(Incidents.event_location == user_input).all()
    elif input_type == "Event Severity":  # Input is entered into Event Severity text field
        sql_query = Incidents.query.filter(Incidents.event_severity == user_input).all()
    elif input_type == "Aircraft Make & Aircraft Model":  # Input is entered as combo; aircraft make & model text fields
        user_input_split = user_input.split(" ")
        sql_query = session.query(Incidents).join(Aircraft).filter(Aircraft.aircraft_make == user_input_split[0] and
                                                                   Aircraft.aircraft_model == user_input_split[1]).all()
    elif input_type == "Event Date & Event Location":  # Input is entered as combo; event date & location text fields
        user_input_split = user_input.split(" ")
        sql_query = session.query(Incidents).filter(Incidents.event_date == user_input_split[0] and
                                                    Incidents.event_location == user_input_split[1]).all()
    elif input_type == "Event Date & Aircraft Registration":
        # Input is entered as combo; event date & aircraft reg num text fields
        user_input_split = user_input.split(" ")
        sql_query = session.query(Incidents).filter(Incidents.event_date == user_input_split[0] and
                                                    Incidents.aircraft_reg_number == user_input_split[1]).all()
    elif input_type == "Event Date & NTSB Number":  # Input is entered as combo; event date & NTSB number text fields
        user_input_split = user_input.split(" ")
        sql_query = session.query(Incidents).filter(Incidents.event_date == user_input_split[0] and
                                                    Incidents.event_ntsb_number == user_input_split[1]).all()
    elif input_type == "Event Date & Aircraft Make":
        # Input is entered as combo; event date & aircraft make text fields
        user_input_split = user_input.split(" ")
        sql_query = sql_query = session.query(Incidents).join(Aircraft).\
            filter(Incidents.event_date == user_input_split[0] and Aircraft.aircraft_make == user_input_split[1]).all()
    elif input_type == "Event Date & Aircraft Model":
        # Input is entered as combo; event date & aircraft model fields
        user_input_split = user_input.split(" ")
        sql_query = sql_query = session.query(Incidents).join(Aircraft). \
            filter(Incidents.event_date == user_input_split[0] and Aircraft.aircraft_model == user_input_split[1]).all()
    elif input_type == "Event Date & Event Severities":
        # Input is entered as combo; event date & casualties fields !!! NEED TO FIX THIS ONE !!!
        user_input_split = user_input.split(" ")
        sql_query = session.query(Incidents).filter(Incidents.event_date == user_input_split[0] and
                                                    Incidents.event_ntsb_number == user_input_split[1])
    elif input_type == "Aircraft Registration & NTSB Number":
        # Input is entered as combo; aircraft reg num & NTSB num fields
        user_input_split = user_input.split(" ")
        sql_query = session.query(Incidents).filter(Incidents.aircraft_reg_number == user_input_split[0] and
                                                    Incidents.event_ntsb_number == user_input_split[1])
    elif input_type == "Aircraft Registration & Event Location":
        # Input is entered as combo; aircraft reg num & event location fields
        user_input_split = user_input.split(" ")
        sql_query = session.query(Incidents).filter(Incidents.aircraft_reg_number == user_input_split[0] and
                                                    Incidents.event_location == user_input_split[1])
    elif input_type == "Aircraft Registration & Event Severity":
        # Input is entered as combo; event date & casualties fields !!! NEED TO FIX THIS ONE !!!
        user_input_split = user_input.split(" ")
        sql_query = session.query(Incidents).filter(Incidents.aircraft_reg_number == user_input_split[0] and
                                                    Incidents.event_severity == user_input_split[1])

    elif input_type == "Event Location & Aircraft Model":
        # Input is entered as combo; event location & aircraft model fields
        user_input_split = user_input.split(" ")
        sql_query = sql_query = session.query(Incidents).join(Aircraft). \
            filter(Incidents.event_location == user_input_split[0] and
                   Aircraft.aircraft_model == user_input_split[1]).all()
    elif input_type == "Event Location & Aircraft Make":
        # Input is entered as combo; event location & aircraft model fields
        user_input_split = user_input.split(" ")
        sql_query = sql_query = session.query(Incidents).join(Aircraft). \
            filter(Incidents.event_location == user_input_split[0] and
                   Aircraft.aircraft_make == user_input_split[1]).all()
    elif input_type == "Event Location & NTSB Number":
        user_input_split = user_input.split(" ")
        sql_query = session.query(Incidents).filter(Incidents.event_location == user_input_split[0] and
                                                    Incidents.event_ntsb_number == user_input_split[1]).all()
    elif input_type == "Event Location & Event Severities":
        # Input is entered as combo; event date & casualties fields !!! NEED TO FIX THIS ONE !!!
        user_input_split = user_input.split(" ")
        sql_query = session.query(Incidents).filter(Incidents.event_location == user_input_split[0] and
                                                    Incidents.event_severity == user_input_split[1])

    index(sql_query)
"""

#this runs at the start of the program
@app.route('/')
def index():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT COUNT(*) FROM Aircraft;')
    result = cur.fetchall()
    cur.close()
    conn.close()
    return render_template('index.html', result=result)

# template for requesting user entered info and returning query result
@app.route("/countaircraft", methods=['POST'])
def countaircraft():
    aircraft_model = request.form["aircraft_model"]
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT COUNT(*) FROM Aircraft WHERE Aircraft.aircraft_model=\'' + aircraft_model + '\';')
    result = cur.fetchall()
    cur.close()
    conn.close()
    return render_template("index.html", result=result)
    
# queries 
# Select aircraft with an incident on user date
@app.route("/aircraftIncidentOnDate", methods=['POST'])
def aircraftIncidentOnDate():
    incident_date = request.form["incident_date"]
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT DISTINCT Aircraft.aircraft_reg_number FROM Aircraft, Incidents WHERE Aircraft.aircraft_reg_number=Incidents.aircraft_reg_number AND Incidents.event_date=\'' + incident_date + '\';')
    resultQuery1 = cur.fetchall()
    cur.close()
    conn.close()
    return render_template("index.html", resultQuery1=resultQuery1)
    
# Select all incidents by aircraft model
@app.route("/incidentsByModel", methods=['POST'])
def incidentsByModel():
    aircraft_model2 = request.form["aircraft_model2"]
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT DISTINCT Incidents.event_ntsb_number FROM Aircraft, Incidents WHERE Aircraft.aircraft_reg_number=Incidents.aircraft_reg_number AND Aircraft.aircraft_model=\'' + aircraft_model2 + '\';')
    resultQuery2 = cur.fetchall()
    cur.close()
    conn.close()
    return render_template("index.html", resultQuery2=resultQuery2)

# Insert an aircraft
@app.route("/insertAircraft", methods=['POST'])
def insertAircraft():
    aircraft_model_insert = request.form["aircraft_model_insert"]
    aircraft_make_insert = request.form["aircraft_make_insert"]
    aircraft_reg_num_insert = request.form["aircraft_reg_num_insert"]
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('INSERT INTO Aircraft VALUES (' + aircraft_reg_num_insert + ', NULL, \'' + aircraft_make_insert + '\', \'' + aircraft_model_insert + '\'); SELECT * FROM Aircraft WHERE aircraft_reg_number=\'' + aircraft_reg_num_insert + '\';')
    result_insert = cur.fetchall()
    cur.close()
    conn.close()
    return render_template("index.html", result_insert=result_insert)


